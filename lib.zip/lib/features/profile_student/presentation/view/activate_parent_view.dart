import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:learnify_app/core/utils/color.dart';

import '../../../../core/Api/dio_consumer.dart';
import '../../../../core/Api/endpoints.dart';
import '../../../auth/data/repo/auth_repo.dart';
import '../../../auth/presentation/view_models/auth_cubit.dart';
import '../../../auth/presentation/view_models/auth_state.dart';

class ActivateParentView extends StatefulWidget {
  const ActivateParentView({super.key});

  @override
  State<ActivateParentView> createState() => _ActivateParentViewState();
}

class _ActivateParentViewState extends State<ActivateParentView> {
  String? generatedCode;
  bool isLoading = false;

  void _generateCode() {
    setState(() {
      isLoading = true;
    });

    // Simulate API call
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        generatedCode = 'ABC123XYZ';
        isLoading = false;
      });
    });
  }

  void _copyToClipboard() {
    if (generatedCode != null) {
      Clipboard.setData(ClipboardData(text: generatedCode!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Code copied to clipboard!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Activate Code to Parent',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: BlocProvider(
        create: (_) => AuthCubit(
          AuthRepo(
            api: DioConsumer(dio: Dio(), baseUrl: Endpoints.baseAuthUrl),
          ),
        ),
        child: const ActivateParentViewWidget(),
      ),
    );
  }
}

class ActivateParentViewWidget extends StatefulWidget {
  const ActivateParentViewWidget({super.key});

  @override
  State<ActivateParentViewWidget> createState() =>
      _ActivateParentViewWidgetState();
}

class _ActivateParentViewWidgetState extends State<ActivateParentViewWidget> {
  final _formKey = GlobalKey<FormState>();
  final _codeCtl = TextEditingController();
  final _emailCtl = TextEditingController();
  final _passwordCtl = TextEditingController();
  final _firstCtl = TextEditingController();
  final _lastCtl = TextEditingController();

  @override
  void dispose() {
    _codeCtl.dispose();
    _emailCtl.dispose();
    _passwordCtl.dispose();
    _firstCtl.dispose();
    _lastCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AuthCubit, AuthState>(
      listener: (context, state) {
        if (state is GenerateParentCodeFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }

        if (state is ActivateAccountSuccess) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Parent activated successfully')),
          );
          Navigator.pop(context);
        }

        if (state is ActivateAccountFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }
      },
      builder: (context, state) {
        String? code;
        if (state is GenerateParentCodeSuccess) code = state.model.code;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.qr_code_2,
                    size: 80,
                    color: AppColors.primaryColor,
                  ),
                ),

                const SizedBox(height: 24),

                TextFormField(
                  controller: _codeCtl,
                  decoration: const InputDecoration(labelText: 'Code'),
                ),

                TextFormField(
                  controller: _emailCtl,
                  decoration: const InputDecoration(labelText: 'Parent Email'),
                  keyboardType: TextInputType.emailAddress,
                ),

                TextFormField(
                  controller: _passwordCtl,
                  decoration: const InputDecoration(labelText: 'Password'),
                  obscureText: true,
                ),

                TextFormField(
                  controller: _firstCtl,
                  decoration: const InputDecoration(labelText: 'First Name'),
                ),

                TextFormField(
                  controller: _lastCtl,
                  decoration: const InputDecoration(labelText: 'Last Name'),
                ),

                const SizedBox(height: 16),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: state is GenerateParentCodeLoading
                        ? null
                        : () {
                            context.read<AuthCubit>().generateParentCode();
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: state is GenerateParentCodeLoading
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text('Generate Code'),
                  ),
                ),

                const SizedBox(height: 12),

                if (code != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.primaryColor),
                    ),
                    child: Row(
                      children: [
                        Expanded(child: Text(code)),
                        IconButton(
                          onPressed: () {
                            final copy = code ?? '';
                            Clipboard.setData(ClipboardData(text: copy));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Code copied')),
                            );
                          },
                          icon: const Icon(Icons.copy),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: state is ActivateAccountLoading
                        ? null
                        : () {
                            final codeVal = _codeCtl.text.isNotEmpty
                                ? _codeCtl.text
                                : code ?? '';
                            context.read<AuthCubit>().activateParent(
                              code: codeVal,
                              email: _emailCtl.text,
                              password: _passwordCtl.text,
                              firstName: _firstCtl.text,
                              lastName: _lastCtl.text,
                            );
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: state is ActivateAccountLoading
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text('Activate Parent'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
