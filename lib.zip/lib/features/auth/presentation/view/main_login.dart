import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:learnify_app/features/auth/presentation/view/login.dart';

import '../../../../core/Api/dio_consumer.dart';
import '../../../../core/Api/endpoints.dart';
import '../../data/repo/auth_repo.dart';
import '../view_models/auth_cubit.dart';
import 'activate_account_view.dart';

class MainLogin extends StatelessWidget {
   MainLogin({super.key});
    bool isParentApp = false;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AuthCubit(AuthRepo(api: DioConsumer(dio: Dio(), baseUrl: Endpoints.baseAuthUrl))),
      child: isParentApp==true? ActivateAccountView(isParentApp: true,) :LoginScreen(),
    );
  }
}

