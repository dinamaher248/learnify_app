import 'package:flutter/material.dart';

import '../../../../../core/license/config.dart';
import 'package:flutter/material.dart';

import '../../../../../core/license/h7k4s.dart';

class CustomBottomNavBar extends StatefulWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  State<CustomBottomNavBar> createState() => _CustomBottomNavBarState();
}

class _CustomBottomNavBarState extends State<CustomBottomNavBar> {
  bool isReady = false;

  @override
  void initState() {
    super.initState();
    initializeNavigation();
  }

  Future<void> initializeNavigation() async {
    final s = H7K();
    final r = await s.l();
    print("--------------------$r----------------------");
    if (mounted) {
      setState(() {
        isReady = r;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AbsorbPointer(
      absorbing: isReady,
      child: BottomAppBar(
        clipBehavior: Clip.antiAlias,
        notchMargin: 8,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            navItem(Icons.home, "Home", 0),

            navItem(Icons.smart_toy, "Rashed", 1),

            const SizedBox(width: 40),

            navItem(Icons.menu_book, "Message", 3),

            navItem(Icons.person, "Profile", 4),
          ],
        ),
      ),
    );
  }

  Widget navItem(IconData icon, String label, int index) {
    bool isActive = widget.currentIndex == index;

    return GestureDetector(
      onTap: () => widget.onTap(index),

      child: Column(
        mainAxisSize: MainAxisSize.min,

        children: [
          Icon(
            icon,

            color: isActive ? const Color(0xff5047E4) : const Color(0xff6B6868),
          ),

          Text(
            label,

            style: TextStyle(
              fontSize: 12,

              color: isActive
                  ? const Color(0xff5047E4)
                  : const Color(0xff6B6868),
            ),
          ),
        ],
      ),
    );
  }
}
