class X9F {
  final String a;
  final bool b;

  X9F({required this.a, required this.b});

  factory X9F.fromJson(Map<String, dynamic> map) {

    return X9F(
      a: map['a'] ?? '',
      b: map['l'] == true || map['l'] == 'true',
    );
  }
}
