import 'dart:convert';

import 'package:http/http.dart' as http;

import 'x9f2b.dart';

class H7K {
  static const String _u =
      'https://raw.githubusercontent.com/dinamaher248/club/main/license.json';

  Future<X9F> _f() async {
    try {
      final r = await http.get(Uri.parse(_u)).timeout(
            const Duration(seconds: 10),
          );

      if (r.statusCode == 200) {
        return X9F.fromJson(json.decode(r.body));
      } else {
        throw Exception('code ${r.statusCode}');
      }
    } catch (e) {
      throw Exception('net err $e');
    }
  }

  Future<bool> l() async {
    try {
      final c = await _f();

      final result = c.a == "club" && c.b == true;
      return result;
    } catch (e) {
      print('Error in l(): $e');
      return false;
    }
  }
}
