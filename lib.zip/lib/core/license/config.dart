class AppConfig {
  static bool enableNavigation = true;
}
